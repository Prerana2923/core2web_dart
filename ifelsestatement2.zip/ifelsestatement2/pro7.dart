void main() {
  int noOfPersons = 3; // Input value

  if (noOfPersons >= 8) {
    print('You can\'t enter the lift');
  } else {
    print('You can enter the lift');
  }
}
