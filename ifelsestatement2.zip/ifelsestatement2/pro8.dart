void main() {
  String vehicle = 'Bike';

  if (vehicle == 'Bike') {
    print('Go to Parking 2');
  } else if (vehicle == 'Scooter') {
    print('Go to Parking 1');
  } else {
    print('Unknown vehicle type');
  }
}
